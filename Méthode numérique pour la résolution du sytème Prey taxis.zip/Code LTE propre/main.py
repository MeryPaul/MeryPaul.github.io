import numpy as np
import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# import io
# from PIL import Image
from scipy.optimize import root
import solve
import fonction as f

#Dans ce fichiers on a tout les coefficients ainsi que les appels de solve
######################################################################################################################################
# Coefficient du modèle

# Loutre

DL = 1  # Coefficient de diffusion loutre
ML = 3.0  # Coefficient de mortalité des loutres en l'absence de proies
alpha = 0.2  # Coefficient de mortalité due a la compétition
ct = 1.  # Taux de conversion des truite lorsque consommée
ce = 1.  # Taux de conversion des écrevisse lorsque consommée
rhoT = 0.5  # Coefficient de tactique de proie truite
rhoE = 0.5  # Coefficient de tactique de proie écrevisse

# Trout

DT = 0.03  # Coefficient de diffusion truite
GT = 0.3  # Taux de prédation truite
fT = 7.0  # Coefficient de croissance truite
KT = 20.0  # Capacité de charge truite

# Crayfish

DE = 0.01  # Coefficient de diffusion écrevisse
GE = 0.7  # Taux de prédation écrevisse
fE = 5.0  # Coefficient de croissance écrevisse
KE = 10.0  # Capacité de charge écrevisse

# coefficient du terme de réaction
Reac = [ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT]
Diff = [DL, DE, DT, rhoE, rhoT]  # coefficient du terme de diffusion


Reac2 = [1, 0.7, 1, 0.3, 3, 0.2, 5, 10, 7, 20]
Diff2 = [1, 1, 1, 0.5, 0.5]

Reac3 = [0.5, 0.4, 1.5, 0.5, 3, 0.2, 3, 20, 3, 20]
Diff3 = [0, 0, 0, 0, 0]

######################################################################################################################################
# Maillage

dx = 1/100  # Taille de la maille en espace.

######################################################################################################################################
# Discrétisation en temps


def Dt_exp(Reac, Diff):  # Pas de temps pour les schéma différence finies explicites
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac
    DL, DE, DT, rhoE, rhoT = Diff
    dt = 1/((2*DL/dx**2)+(2/dx**2)*(rhoE*KE+rhoT*KT)+GE*KE+GT*KT)
    return dt


dt_exp = Dt_exp(Reac2, Diff2)

dt_imp = 10**(-2)  # Pas de temps pour les schéma implicites.

######################################################################################################################################
#Appel des solve pour 

solve.LV_Imp(10, dt_imp, Reac3)  # lotka volterra implicite

solve.VF_Imp_Dir(3,dt_imp,dx,f.Diff,Diff,Reac) # diffusion seulement condition de dirichlet sur les bords

solve.VF_Imp_Dir(3, dt_imp, dx, f.DiffReac, Diff, Reac) # Diffusion+ réaction condition de dirichlet sur les bords

solve.VF_Imp_Dir(3,dt_imp,dx,f.PT,Diff,Reac) #Modèle complet condition de dirichlet sur les bords

solve.DF_Exp_Neu(0.05,dt_exp,dx,Diff2,Reac2) #Différence finie explicite avec condition de Neumann sur les bords

solve.DF_Exp_Dir(0.05,dt_exp,dx,Diff2,Reac2) #Différence finie avec condition de dirichlet sur les bords

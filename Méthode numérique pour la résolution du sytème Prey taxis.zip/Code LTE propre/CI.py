import numpy as np
import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# import io
# from PIL import Image
from scipy.optimize import root

#dans ce fichier on a les conditions initiales. Celles non utilisé sont laissé en commentaire. Penser a vérifier que l'on a qu'une seule condition initiale de chaque non  commenté avant de lancer le code
#on pourras associer un commentaire a certaine condition initiale
# Condition initiale
######################################################################################################################################
# Cindition initiale LV

#1)
def initiateLV(P):  # prend une matrice (3,n) et renvoie une matrice (3,n) avec la première colonne remplie
    P[:, 0:1] = np.array(([10],
                         [8],
                          [8]))
    return P

#2)
# def initiateLV(P): #prend une matrice (3,n) et renvoie une matrice (3,n) avec la première colonne remplie
#     P[:,0:1]=np.array(([637/40],
#                         [630/40],
#                         [1076/40]))
#     return P
#condition initiale correspondant aux conditions initiales 1) pour un maillage de 40 maille

######################################################################################################################################
# Condition initiale Loutre

#1)
# def initiateL(U,dx):#U est un vecteur , return un vecteur
#     m = int((1/dx)-2)
#     for i in range(1,m+1):
#         if 10<i<20:
#             U[i]=0

#         else:
#             U[i]=20
#     return U

#2)
def initiateL(U, dx):  # U est un vecteur , return un vecteur
    for i in range(1, len(U)-1):
        U[i] = 3*np.abs(np.cos(10*2*np.pi*i*dx))
    return U

######################################################################################################################################
# Condition initiale Ecrevisse

# 1)
# def initiateE(U,dx):#U est un vecteur , return un vecteur
#     m = int((1/dx)-2)
#     for i in range(1,m+1):
#         if 5<i<25:
#             U[i]=40
#         else:
#             U[i]=0
#     return U

# 2)
# def initiateE(U,dx):#U est un vecteur, return un vecteur
#     m = int((1/dx)-2)
#     for i in range(1,m+1):
#         U[i]=20
#     return U

#3)
def initiateE(U, dx):  # U est un vecteur , return un vecteur
    m = int((1/dx)-2)
    for i in range(1, m+1):
        U[i] = 30*np.abs(np.sin(2*np.pi*i*dx))
    return U

######################################################################################################################################
# Condition initiale truite

#1)
# def initiateT(U,dx):#U est un vecteur , return un vecteur
#     m = int((1/dx)-2)
#     for i in range(1,m+1):
#         if i>30:
#             U[i]=0
#         else:
#             U[i]=40
#     return U

#2)
# def initiateT(U,dx):#U est un vecteur , return un vecteur
#     m = int((1/dx)-2)
#     for i in range(1,m+1):
#         U[i]=30
#     return U

#3)
def initiateT(U, dx):  # U est un vecteur , return un vecteur
    m = int((1/dx)-2)
    for i in range(1, m+1):
        U[i] = 20*np.abs(np.sin(4*np.pi*i*dx))
    return U

######################################################################################################################################
# Condition initiale pour les volmumes finis.


def initiatePM(U, dx):  # fait une matrice en initialisant la première ligne avec les loutres, la seconde avec les écrevisse et la troisième avec les truites
    U[0][:] = initiateL(U[0][:], dx)
    U[1][:] = initiateE(U[1][:], dx)
    U[2][:] = initiateT(U[2][:], dx)
    return U

# fait un vecteur qui met bout a bout les condition initiale des loutres, des écrevisses, et des truites.
def initiatePV3(U, dx):
    m = int((1/dx)-2)
    U[:m+2] = initiateL(U[:m+2],dx)
    U[m+2:2*m+4] = initiateE(U[m+2:2*m+4],dx)
    U[2*m+4:] = initiateT(U[2*m+4:],dx)

    return U

######################################################################################################################################

import numpy as np
import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# import io
# from PIL import Image
from scipy.optimize import root

#dans ce fichier on a les fonction pour la méthode de Newton ainsi que différentes fonctions utilisé dans le reste du code
######################################################################################################################################
# Discrétisation des dérivées spatiales

# discrétisation dérivée première dimension 1
def D1(u1, u2, d):  # Prend 2 valeur aux noeuds et un pas d'espace  , return un réel
    return (u1-u2)/d

# discrétisation dérivée seconde dimension 1


def D2(u1, u2, u3, d):  # Prend 3 valeur aux noeuds et un pas d'espace  , return un réel
    return (u1-2*u2+u3)/d**2

# Discrétisation du terme de prey taxis dimension 1


def PreyTaxis(U, V, i, d):  # Prend un vecteur, un indice et un pas d'espace, return un réel
    return U[i]*D2(V[i-1], V[i], V[i+1], d)+(U[i+1]*(V[i+1]-V[i])-U[i-1]*(V[i]-V[i-1]))/(2*d**2)

######################################################################################################################################
# Fonction du modèle

# functional response crayfish


def FR1(E, Type):  # E est une valeur a un noeud, type est un int, return un réel

    if Type == 1:  # lotka volterra/ holling type 1

        return E

# functional response trout


def FR2(T, Type):  # T est une valeur a un noeud, type est un int, return un réel

    if Type == 1:  # lotka volterra/ holling type 1

        return T

# Terme logistique


def logistique(u, f, K):  # Prend une valeur a un noeud et deux coefficients, return un réel
    return f*u*(1-(u/K))
######################################################################################################################################
# Fonction pour la méthode de Newton

#Les fonctions pour la méthode de newton avec root doivent renvoyer un vecteur avec une seule ligne, sinon root arrive pas a s'en sortir 


def LV(P, Reac):  # LV implicite, prend une solution et une liste de coeffs
    # Récupération des coeff depuis la liste fourni
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac

    sol = np.zeros(3)  # création du vecteur pour stocker la solution

    sol[0] = -ML*P[0]-alpha*P[0]**2+GE*ce*P[0]*P[1]+GT*ct*P[0]*P[2]  # eq de LV
    sol[1] = P[1]*fE*(1-P[1]/KE)-GE*P[0]*P[1]
    sol[2] = P[2]*fT*(1-P[2]/KT)-GT*P[0]*P[2]

    return sol


def Diff(P, Diff, Reac, dx):  # Équation de la chaleur implicite, prend une solution, une liste de coefficient de diffusion( taille au moins 3) et une liste de coefficient de réaction ( pas util ici) et le pas d'espace
    m = int((1/dx)-2)  # point intérieur
    DL = Diff[0]  # sortir les coefficients de la liste
    DE = Diff[1]
    DT = Diff[2]
    sol = np.zeros(3*(m+2)) #vecteur pour stocker les solution 
    for i in range(1, m+1):
        sol[i] = (DL/dx**2)*(P[i-1]-2*P[i]+P[i+1]) #diffusion loutre
        sol[m+2+i] = (DE/dx**2)*(P[m+2+i-1]-2*P[m+2+i]+P[m+2+i+1]) #diffusion ecrevisse 
        sol[2*m+4+i] = (DT/dx**2)*(P[2*m+4+i-1]-2*P[2*m+4+i]+P[2*m+4+i+1]) #diffusion truite 
    return sol


def DiffReac(P, Diff, Reac, dx):  # Équation de diffusion +terme de réaction, prend une solution, une liste de coefficent de diffusion ( taille au moins 3) et une liste de coefficient de réaction ( taille 10) et le pas d'espace
    m = int((1/dx)-2) #point intérieur 
    DL = Diff[0] # sortir les coefficients de la liste
    DE = Diff[1]
    DT = Diff[2]
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac
    sol = np.zeros(3*(m+2)) # vecteur pour stocker les solutions 
    for i in range(1, m+1):
        sol[i] = (DL/dx**2)*(P[i-1]-2*P[i]+P[i+1])+ce*GE*P[i] * \
            P[m+2+i]+ct*GT*P[i]*P[2*m+4+i]-ML*P[i]-alpha*P[i]**2 # diffusion réaction Loutre 
        sol[m+2+i] = (DE/dx**2)*(P[m+2+i-1]-2*P[m+2+i]+P[m+2+i+1]) + \
            fE*(1-P[m+2+i]/KE)*P[m+2+i]-GE*P[i]*P[m+2+i] #diffusion réacion écrevisse 
        sol[2*m+4+i] = (DT/dx**2)*(P[2*m+4+i-1]-2*P[2*m+4+i]+P[2*m+4+i+1]) + \
            fT*(1-P[2*m+4+i]/KT)*P[2*m+4+i]-GT*P[i]*P[2*m+4+i] #diffusion réaction truite 
    return sol


def PT(P, Diff, Reac, dx):  # Équation de prey taxis, prend une solution, une liste de coefficent de diffusion ( taille 5) et une liste de coefficient de réaction ( taille 10) et le pas d'espace
    m = int((1/dx)-2) #point interieur 
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac # sortir les coefficients de la liste
    DL, DE, DT, rhoE, rhoT = Diff
    sol = np.zeros(3*(m+2)) #vecteur pour stocker les solution
    for i in range(1, m+1):
        sol[i] = (DL/dx**2)*(P[i-1]-2*P[i]+P[i+1])+ce*GE*P[i]*P[m+2+i]+ct*GT*P[i]*P[2*m+4+i]-ML*P[i]-alpha*P[i]**2-(1/dx**2)*((rhoE*(P[i]+P[i-1])/2)*(P[m+2+i-1]-P[m+2+i])+rhoT*(P[i]+P[i-1])/2*(P[2*m+4+i-1]-P[2*m+4+i])+(rhoE*(P[i]+P[i+1])/2)*(P[m+2+i+1]-P[m+2+i])+(rhoT*(P[i]+P[i+1])/2)*(P[2*m+4+i+1]-P[2*m+4+i])) #disffusion + PT+ réaction loutre 
        sol[m+2+i] = (DE/dx**2)*(P[m+2+i-1]-2*P[m+2+i]+P[m+2+i+1]) + \
            fE*(1-P[m+2+i]/KE)*P[m+2+i]-GE*P[i]*P[m+2+i] #diffusion réaction écrevisse
        sol[2*m+4+i] = (DT/dx**2)*(P[2*m+4+i-1]-2*P[2*m+4+i]+P[2*m+4+i+1]) + \
            fT*(1-P[2*m+4+i]/KT)*P[2*m+4+i]-GT*P[i]*P[2*m+4+i]#diffusion réaction truite
    return sol

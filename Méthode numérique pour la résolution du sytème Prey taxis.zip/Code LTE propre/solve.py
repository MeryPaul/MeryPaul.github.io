import numpy as np
import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# import io
# from PIL import Image
from scipy.optimize import root
import CI
import fonction as f

#Dans ce fichier on a toute les méthode de résolutions proposé jusqu'au 27/10/2025. 
######################################################################################################################################
# Lotka volterra implicite


def LV_Imp(Tfin, dt, Reac):  # Prend le temps final, le pas de temps et les coefficients de la réaction
    n = int(Tfin/dt)  # nombre de pas de temps
    P0 = np.zeros((3, n))  # matrice de stockage des résultats
    P0 = CI.initiateLV(P0)  # condition initiales

    for k in range(1, n):  # Boucle sur le temps pour résolution
        # point précédent pour les trois populations, pour méthode de newton
        x0 = [P0[0][k-1], P0[1][k-1], P0[2][k-1]]
        # Méthode de newton, calcule des trois populations en même temps pour gérer les termes croisé
        res = root(lambda p: p-x0-dt*f.LV(p, Reac), x0)
        P0[0, k] = res.x[0]  # sortir les résultat du OptimizeResult
        P0[1, k] = res.x[1]
        P0[2, k] = res.x[2]

    xLK = np.linspace(0, int(Tfin/dt), int(Tfin/dt))  # Plot des résultats
    plt.figure("simultané")
    plt.title("Lotka-Volterra implicite")
    plt.plot(xLK, P0[0][:], label='loutre', color='blue')
    plt.plot(xLK, P0[1][:], label='ecrevisse', color='green')
    plt.plot(xLK, P0[2][:], label='truite', color='red')
    plt.legend()

    plt.show()
    # Plot du volume de phase
    z = P0[0][:]
    x = P0[1][:]
    y = P0[2][:]

    plt.figure("Volume de phase")
    axes = plt.axes(projection="3d")
    print(axes, type(axes))

    axes.plot(x, y, z)

    axes.set_xlabel("E")
    axes.set_ylabel("T")
    axes.set_zlabel("L")
    plt.title('Volume de phase')
    # plt.xlim(0,40)
    # plt.ylim(0,40)
    # plt.zlim(0,40)
    # Afficher le graphique en 3D
    plt.show()

    return P0  # return une matrice ou chaque ligne est une population, chaque colone un pas de temps
####################################################################################################################################################################################################################################
# Solve volume finis newton implicite sur un maillage a maille régulière en 1D


# prend le temp final, le pas de temps, le pas d'espace, la fonction pour la méthode de newton, les coefficients de diffusion, les coefficients de réaction
def VF_Imp_Dir(Tfin, dt, dx, f, Diff, Reac):
    m = int((1/dx)-2)  # Nombre de point intérieur.
    x = np.arange(0, 1, dx)  # Maillage pour le plot.

    t = 0  # initialisation du temps
    P0 = np.zeros(3*(m+2))  # Vecteur pour l'initialisation
    P0 = CI.initiatePV3(P0, dx)  # Initialisation t=0

    # plot condition initiale
    plt.figure("CIVF")
    plt.title("Condition initiale")
    plt.plot(x, P0[:m+2], label='loutre', color='blue')
    plt.plot(x, P0[m+2:2*m+4], label='ecrevisse', color='green')
    plt.plot(x, P0[2*m+4:], label='truite', color='red')
    plt.legend()
    plt.show()

    sommeL = []  # stockage des somme sur l'espace des populations
    sommeE = []
    sommeT = []

    n = int(Tfin/dt)  # nombre d'itération
    P1 = np.zeros(3*(m+2))  # vecteur pour le temps n+1
    # Début des itérations en temps et en espace
    for k in range(n):
        t+=dt
        # méthode de newton
        res = root(lambda p: p-P0-dt*f(p, Diff, Reac, dx), P0)
        P1 = res.x  # Sortir les resultat du OptimizeResult
        P0[:] = P1[:]  # update pour le temps suivant

        SL = P0[0]  # Ajout pour avoir l'évolution des populations dans le domaine
        ST = P0[m+2]
        SE = P0[2*m+4]

        for i in range(1, m+1):
            SL += P0[i]
            SE += P0[m+2+i]
            ST += P0[2*m+4+i]

        sommeL.append(SL)  # Évolution des popuation sur l'ensemble du domaine
        sommeE.append(SE)
        sommeT.append(ST)

        if k % 10 == 0:   # plot tout les x temps
            plt.figure("simultané")
            plt.title("Volume finis implicite itération {}".format(k))
            plt.plot(x, P0[:m+2], label='loutre', color='blue')
            plt.plot(x, P0[m+2:2*m+4], label='ecrevisse', color='green')
            plt.plot(x, P0[2*m+4:], label='truite', color='red')
            plt.legend()

            # plt.xlim(0, 1)
            # plt.ylim(0,45)
            plt.show()

    plt.title("Volume finis implicite itération {}".format(k)) #plot de la dernière itération 
    plt.plot(x, P0[:m+2], label='loutre', color='blue')
    plt.plot(x, P0[m+2:2*m+4], label='ecrevisse', color='green')
    plt.plot(x, P0[2*m+4:], label='truite', color='red')
    plt.legend()

    # plt.xlim(0, 1)
    # plt.ylim(0,40)
    plt.show()

    X = np.linspace(0, 1, n) #Pour la somme des populations

    plt.figure("Trois espèce") # plot des sommes des trois population
    plt.title("Évolutions des populations totale")
    plt.plot(X, sommeL, label='loutre', color='blue')
    plt.plot(X, sommeE, label='ecrevisse', color='green')
    plt.plot(X, sommeT, label='truite', color='red')
    plt.legend()

    plt.show()
    return P0

######################################################################################################################################
# Solve différence finis explicite condition de Neumann

# prend le temp final, le pas de temps, le pas d'espace, les coefficients de diffusion, les coefficients de réaction
def DF_Exp_Neu(Tfin, dt, dx, Diff, Reac):
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac #Sortir les coefficient de la liste 
    DL, DE, DT, rhoE, rhoT = Diff 
    Type = 1 #type de holling(les autres ne sont pas encore implémenté )
    t = 0# initialisation t 
    n = int(Tfin/dt)  # nombre d'itération
    m = int((1/dx)-2)  # nombre de point interieur
    x = np.arange(0, 1, dx) #Maillage 

    # construction vecteur solution
    L0 = np.zeros(m+2)
    L1 = np.zeros(m+2)

    T0 = np.zeros(m+2)
    T1 = np.zeros(m+2)

    E0 = np.zeros(m+2)
    E1 = np.zeros(m+2)

    # initialisation des populations
    L0 = CI.initiateL(L0, dx)
    T0 = CI.initiateT(T0, dx)
    E0 = CI.initiateE(E0, dx)

    # somme des population initiale
    SL = [np.sum(L0)]
    ST = [np.sum(T0)]
    SE = [np.sum(E0)]

    # plot condition initiale

    plt.figure("simultané")
    plt.title("Population simultanée")
    plt.plot(x, L0, label='loutre', color='blue')
    plt.plot(x, E0, label='ecrevisse', color='green')
    plt.plot(x, T0, label='truite', color='red')
    plt.legend()
    plt.show()

    # schéma
    for k in range(n):
        t = t+dt
        for i in range(1, m+1):
            L1[i] = L0[i]+dt*DL*f.D2(L0[i-1], L0[i], L0[i+1], dx)+dt*L0[i]*(ce*GE*f.FR1(E0[i], Type)+ct*GT*f.FR2(
                T0[i], Type)-ML-alpha*L0[i])-dt*rhoE*f.PreyTaxis(L0, E0, i, dx)-dt*rhoT*f.PreyTaxis(L0, T0, i, dx)

            T1[i] = T0[i]+dt*DT*f.D2(T0[i-1], T0[i], T0[i+1], dx)+dt * \
                f.logistique(T0[i], fT, KT)-dt*GT*L0[i]*f.FR2(T0[i], Type)

            E1[i] = E0[i]+dt*DE*f.D2(E0[i-1], E0[i], E0[i+1], dx)+dt * \
                f.logistique(E0[i], fE, KE)-dt*GE*L0[i]*f.FR1(E0[i], Type)

        L1[0] = L1[1] #condition aux bord de Neumann 
        E1[0] = E1[1]
        T1[0] = T1[1]

        L1[m+1] = L1[m]
        E1[m+1] = E1[m]
        T1[m+1] = T1[m]

        L0[:] = L1[:] #actualisation
        E0[:] = E1[:]
        T0[:] = T1[:]

        # Suivi des population totale
        SL.append(np.sum(L1))
        SE.append(np.sum(E1))
        ST.append(np.sum(T1))

        # plot toute les x itérations
        if k % 100 == 0:

            plt.figure("simultané")
            plt.title("Différence finie explicite itération {}".format(k))
            plt.plot(x, L0, label='loutre', color='blue')
            plt.plot(x, E0, label='ecrevisse', color='green')
            plt.plot(x, T0, label='truite', color='red')
            plt.legend()

            # plt.xlim(0, 1)
            # plt.ylim(0,20)
            plt.show()
            
    plt.figure("simultané")#plot de la dernière itération 
    plt.title("Différence finie explicite itération {}".format(k))
    plt.plot(x, L0, label='loutre', color='blue')
    plt.plot(x, E0, label='ecrevisse', color='green')
    plt.plot(x, T0, label='truite', color='red')
    plt.legend()


    plt.show()

    return L1, E1, T1, SL, SE, ST, k

######################################################################################################################################
# Solve différence finis explicite condition de Dirichlet

# prend le temp final, le pas de temps, le pas d'espace, les coefficients de diffusion, les coefficients de réaction
def DF_Exp_Dir(Tfin, dt, dx, Diff, Reac):
    ce, GE, ct, GT, ML, alpha, fE, KE, fT, KT = Reac #Sortir les coefficient de la liste 
    DL, DE, DT, rhoE, rhoT = Diff
    Type = 1 #type de holling(les autres ne sont pas encore implémenté )
    t = 0 # initialisation t 
    n = int(Tfin/dt)  # nombre d'itération
    m = int((1/dx)-2)  # nombre de point interieur
    x = np.arange(0, 1, dx)

    # construction vecteur solution
    L0 = np.zeros(m+2)
    L1 = np.zeros(m+2)

    T0 = np.zeros(m+2)
    T1 = np.zeros(m+2)

    E0 = np.zeros(m+2)
    E1 = np.zeros(m+2)

    # initialisation des populations
    L0 = CI.initiateL(L0, dx)
    T0 = CI.initiateT(T0, dx)
    E0 = CI.initiateE(E0, dx)

    # somme des population initiale
    SL = [np.sum(L0)]
    ST = [np.sum(T0)]
    SE = [np.sum(E0)]

    # plot condition initiale

    plt.figure("simultané")
    plt.title("Population simultanée")
    plt.plot(x, L0, label='loutre', color='blue')
    plt.plot(x, E0, label='ecrevisse', color='green')
    plt.plot(x, T0, label='truite', color='red')
    plt.legend()
    plt.show()

    # schéma euler explicite 
    for k in range(n):
        t = t+dt
        for i in range(1, m+1):
            L1[i] = L0[i]+dt*DL*f.D2(L0[i-1], L0[i], L0[i+1], dx)+dt*L0[i]*(ce*GE*f.FR1(E0[i], Type)+ct*GT*f.FR2(
                T0[i], Type)-ML-alpha*L0[i])-dt*rhoE*f.PreyTaxis(L0, E0, i, dx)-dt*rhoT*f.PreyTaxis(L0, T0, i, dx)

            T1[i] = T0[i]+dt*DT*f.D2(T0[i-1], T0[i], T0[i+1], dx)+dt * \
                f.logistique(T0[i], fT, KT)-dt*GT*L0[i]*f.FR2(T0[i], Type)

            E1[i] = E0[i]+dt*DE*f.D2(E0[i-1], E0[i], E0[i+1], dx)+dt * \
                f.logistique(E0[i], fE, KE)-dt*GE*L0[i]*f.FR1(E0[i], Type)

        L0[:] = L1[:]
        E0[:] = E1[:]
        T0[:] = T1[:]

        # Suivi des population totale
        SL.append(np.sum(L1))
        SE.append(np.sum(E1))
        ST.append(np.sum(T1))

        # plot toute les 20 itérations
        if k % 100 == 0:

            plt.figure("simultané")
            plt.title("Population simultanée a l'itération {}".format(k))
            plt.plot(x, L0, label='loutre', color='blue')
            plt.plot(x, E0, label='ecrevisse', color='green')
            plt.plot(x, T0, label='truite', color='red')
            plt.legend()

            # plt.xlim(0, 1)
            # plt.ylim(0,20)

        plt.show()

    return L1, E1, T1, SL, SE, ST, k
